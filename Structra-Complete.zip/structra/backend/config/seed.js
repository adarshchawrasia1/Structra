/**
 * config/seed.js
 * Run once: node config/seed.js
 * Populates MongoDB with contractors and cities.
 */
const mongoose = require('mongoose');
const dotenv   = require('dotenv');
dotenv.config({ path: require('path').join(__dirname, '../.env') });

const Contractor = require('../models/Contractor');
const City       = require('../models/City');

const contractors = [
  // NAGPUR
  { name:'Ravi Constructions Pvt Ltd',  city:'nagpur',    region:'Maharashtra',  rating:4.8, totalReviews:142, phone:'9876543210', email:'ravi@raviconstructions.in',   specialization:['Residential','Commercial'], minRate:1750, maxRate:1900, experience:18, completedProjects:320, verified:true, featured:true  },
  { name:'Shiva Builders Pvt Ltd',      city:'nagpur',    region:'Maharashtra',  rating:4.6, totalReviews:89,  phone:'9123456789', email:'info@shivabuilders.com',       specialization:['Residential','Warehouse'],  minRate:1800, maxRate:2000, experience:12, completedProjects:210, verified:true, featured:false },
  { name:'Prime Infra Group',           city:'nagpur',    region:'Maharashtra',  rating:4.5, totalReviews:67,  phone:'9988776655', email:'prime@infragroup.co.in',        specialization:['Commercial'],              minRate:1700, maxRate:1950, experience:10, completedProjects:180, verified:true, featured:false },
  // PUNE
  { name:'Konark Constructions',        city:'pune',      region:'Maharashtra',  rating:4.9, totalReviews:315, phone:'9345678901', email:'hello@konarkconstructions.in',  specialization:['Premium','Residential'],   minRate:2200, maxRate:2500, experience:28, completedProjects:600, verified:true, featured:true  },
  { name:'Pune Urban Developers',       city:'pune',      region:'Maharashtra',  rating:4.7, totalReviews:203, phone:'9234567890', email:'contact@puneurbandevelopers.com', specialization:['Residential','Commercial'],minRate:2100, maxRate:2400, experience:22, completedProjects:450, verified:true, featured:true  },
  { name:'Aakash Build Co.',            city:'pune',      region:'Maharashtra',  rating:4.4, totalReviews:98,  phone:'9456789012', email:'aakash@buildco.in',             specialization:['Residential'],             minRate:2000, maxRate:2300, experience:9,  completedProjects:155, verified:true, featured:false },
  // MUMBAI
  { name:'Oberoi Realty Works',         city:'mumbai',    region:'Maharashtra',  rating:4.9, totalReviews:428, phone:'9567890123', email:'works@oberoirealty.com',        specialization:['Premium','Commercial'],    minRate:2900, maxRate:3200, experience:35, completedProjects:800, verified:true,  featured:true  },
  { name:'Lodha Construction',          city:'mumbai',    region:'Maharashtra',  rating:4.8, totalReviews:512, phone:'9678901234', email:'build@lodhaconstruction.com',   specialization:['Premium','Residential'],   minRate:3000, maxRate:3500, experience:40, completedProjects:1200,verified:true,  featured:true  },
  { name:'Mumbai Metro Builders',       city:'mumbai',    region:'Maharashtra',  rating:4.5, totalReviews:187, phone:'9789012345', email:'info@mumbaimetrobuilders.com',  specialization:['Residential'],             minRate:2800, maxRate:3100, experience:15, completedProjects:290, verified:true, featured:false },
  // DELHI
  { name:'Delhi Master Builders',       city:'delhi',     region:'Delhi NCR',    rating:4.7, totalReviews:234, phone:'9890123456', email:'delhi@masterbuilders.in',       specialization:['Commercial','Residential'],minRate:2700, maxRate:3000, experience:20, completedProjects:410, verified:true, featured:true  },
  { name:'NCR Infra Solutions',         city:'delhi',     region:'Delhi NCR',    rating:4.6, totalReviews:176, phone:'9901234567', email:'ncr@infrasolutions.com',        specialization:['Commercial','Warehouse'],  minRate:2600, maxRate:2900, experience:14, completedProjects:280, verified:true, featured:false },
  // BANGALORE
  { name:'Brigade Constructions',       city:'bangalore', region:'Karnataka',    rating:4.8, totalReviews:389, phone:'9012345678', email:'build@brigadeconstructions.com',specialization:['Residential','Premium'],   minRate:2500, maxRate:2800, experience:30, completedProjects:750, verified:true, featured:true  },
  { name:'Prestige Build Works',        city:'bangalore', region:'Karnataka',    rating:4.7, totalReviews:267, phone:'9123450987', email:'info@prestigebuild.in',         specialization:['Premium','Residential'],   minRate:2600, maxRate:3000, experience:25, completedProjects:520, verified:true, featured:true  },
  // HYDERABAD
  { name:'Myhome Constructions',        city:'hyderabad', region:'Telangana',    rating:4.6, totalReviews:198, phone:'9234501876', email:'build@myhomeconstructions.in',  specialization:['Residential','Commercial'],minRate:1900, maxRate:2200, experience:20, completedProjects:380, verified:true, featured:true  },
  // CHENNAI
  { name:'TVS Infrastructure',          city:'chennai',   region:'Tamil Nadu',   rating:4.7, totalReviews:221, phone:'9345012765', email:'build@tvsinfra.in',             specialization:['Commercial','Residential'],minRate:2000, maxRate:2300, experience:22, completedProjects:430, verified:true, featured:true  },
  // PAN INDIA (fallback)
  { name:'National Build Corp',         city:'pan-india', region:'All India',    rating:4.6, totalReviews:890, phone:'18004259000', email:'contact@nationalbuild.in',     specialization:['Residential','Commercial','Warehouse'],minRate:1500, maxRate:3500, experience:25, completedProjects:2000, verified:true, featured:true },
  { name:'IndiaConstruct Pro',          city:'pan-india', region:'All India',    rating:4.4, totalReviews:567, phone:'18001234000', email:'hello@indiaconstructpro.com',  specialization:['Residential','Warehouse'],  minRate:1500, maxRate:3000, experience:18, completedProjects:1400, verified:true, featured:false },
];

const cities = [
  { name:'Nagpur',     slug:'nagpur',     region:'Maharashtra',  baseRate:1800, multiplier:1.00, tier:'tier2', hasContractors:true  },
  { name:'Pune',       slug:'pune',       region:'Maharashtra',  baseRate:2200, multiplier:1.22, tier:'tier1', hasContractors:true  },
  { name:'Mumbai',     slug:'mumbai',     region:'Maharashtra',  baseRate:3000, multiplier:1.67, tier:'metro', hasContractors:true  },
  { name:'Delhi',      slug:'delhi',      region:'Delhi NCR',    baseRate:2800, multiplier:1.56, tier:'metro', hasContractors:true  },
  { name:'Bangalore',  slug:'bangalore',  region:'Karnataka',    baseRate:2600, multiplier:1.44, tier:'metro', hasContractors:true  },
  { name:'Hyderabad',  slug:'hyderabad',  region:'Telangana',    baseRate:2000, multiplier:1.11, tier:'tier1', hasContractors:true  },
  { name:'Chennai',    slug:'chennai',    region:'Tamil Nadu',   baseRate:2100, multiplier:1.17, tier:'tier1', hasContractors:true  },
  { name:'Ahmedabad',  slug:'ahmedabad',  region:'Gujarat',      baseRate:1700, multiplier:0.94, tier:'tier1', hasContractors:false },
  { name:'Kolkata',    slug:'kolkata',    region:'West Bengal',  baseRate:1900, multiplier:1.06, tier:'metro', hasContractors:false },
  { name:'Jaipur',     slug:'jaipur',     region:'Rajasthan',    baseRate:1600, multiplier:0.89, tier:'tier2', hasContractors:false },
  { name:'Lucknow',    slug:'lucknow',    region:'U.P.',         baseRate:1500, multiplier:0.83, tier:'tier2', hasContractors:false },
  { name:'Surat',      slug:'surat',      region:'Gujarat',      baseRate:1750, multiplier:0.97, tier:'tier2', hasContractors:false },
  { name:'Bhopal',     slug:'bhopal',     region:'M.P.',         baseRate:1550, multiplier:0.86, tier:'tier2', hasContractors:false },
  { name:'Coimbatore', slug:'coimbatore', region:'Tamil Nadu',   baseRate:1850, multiplier:1.03, tier:'tier2', hasContractors:false },
  { name:'Indore',     slug:'indore',     region:'M.P.',         baseRate:1600, multiplier:0.89, tier:'tier2', hasContractors:false },
];

(async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/structra');
    console.log('✅  Connected to MongoDB');
    await Contractor.deleteMany({});
    await City.deleteMany({});
    await Contractor.insertMany(contractors);
    console.log(`✅  Seeded ${contractors.length} contractors`);
    await City.insertMany(cities);
    console.log(`✅  Seeded ${cities.length} cities`);
    console.log('\n🎉  Structra database seeded successfully!');
    process.exit(0);
  } catch (err) {
    console.error('❌  Seed error:', err.message);
    process.exit(1);
  }
})();
