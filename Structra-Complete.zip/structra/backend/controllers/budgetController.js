/**
 * controllers/budgetController.js
 */
const { validationResult }  = require('express-validator');
const { calculateBudget }   = require('../services/calculationService');

const calcBudget = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });
    const result = calculateBudget(req.body);
    return res.json({ success: true, data: result });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
};

module.exports = { calcBudget };
