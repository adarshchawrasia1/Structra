/**
 * controllers/contractorController.js
 */
const Contractor = require('../models/Contractor');

// GET /api/contractors?city=nagpur&limit=5
const getContractors = async (req, res) => {
  try {
    const { city, limit = 5, specialization, minRating = 0 } = req.query;
    const filter = { available: true };
    if (city)           filter.city           = city.toLowerCase().trim();
    if (specialization) filter.specialization = { $in: [specialization] };
    if (minRating)      filter.rating         = { $gte: Number(minRating) };

    let contractors = await Contractor
      .find(filter).sort({ featured: -1, rating: -1 }).limit(Number(limit)).select('-__v');

    // Fallback to top national contractors if none found for city
    if (!contractors.length && city) {
      contractors = await Contractor
        .find({ available: true, rating: { $gte: 4.3 } })
        .sort({ rating: -1 }).limit(3).select('-__v');
    }

    return res.json({ success: true, city: city || 'all', count: contractors.length, data: contractors });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
};

const getContractorById = async (req, res) => {
  try {
    const c = await Contractor.findById(req.params.id);
    if (!c) return res.status(404).json({ success: false, message: 'Contractor not found' });
    return res.json({ success: true, data: c });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
};

module.exports = { getContractors, getContractorById };
