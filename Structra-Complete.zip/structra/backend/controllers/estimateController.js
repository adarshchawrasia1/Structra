/**
 * controllers/estimateController.js
 */
const { validationResult } = require('express-validator');
const Estimate             = require('../models/Estimate');
const { calculateEstimate }= require('../services/calculationService');

// POST /api/estimate
const createEstimate = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ success: false, errors: errors.array() });

    const result = calculateEstimate(req.body);

    // Save to DB async (non-blocking)
    const doc = new Estimate({
      ...req.body,
      city:      req.body.city?.toLowerCase(),
      results: {
        totalCost:       result.results.totalCost,
        ratePerSqft:     result.results.ratePerSqft,
        totalAreaSqft:   result.results.totalAreaSqft,
        builtupAreaSqft: result.results.builtupAreaSqft,
        costRangeMin:    result.results.costRangeMin,
        costRangeMax:    result.results.costRangeMax,
      },
      score:     result.score,
      ipAddress: req.ip,
    });
    doc.save().catch(e => console.error('⚠️  Estimate save failed:', e.message));

    return res.status(200).json({ success: true, data: result, estimateId: doc._id });
  } catch (err) {
    console.error('❌ Estimate error:', err);
    return res.status(500).json({ success: false, message: err.message });
  }
};

// GET /api/estimate/:id
const getEstimate = async (req, res) => {
  try {
    const est = await Estimate.findById(req.params.id);
    if (!est) return res.status(404).json({ success: false, message: 'Estimate not found' });
    return res.json({ success: true, data: est });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
};

// GET /api/estimate/stats
const getStats = async (req, res) => {
  try {
    const [total, avgArr, topCities, topQuality] = await Promise.all([
      Estimate.countDocuments(),
      Estimate.aggregate([{ $group: { _id: null, avg: { $avg: '$results.totalCost' } } }]),
      Estimate.aggregate([{ $group: { _id: '$city', count: { $sum: 1 } } }, { $sort: { count: -1 } }, { $limit: 5 }]),
      Estimate.aggregate([{ $group: { _id: '$quality', count: { $sum: 1 } } }, { $sort: { count: -1 } }]),
    ]);
    return res.json({ success: true, data: { totalEstimates: total, averageCost: Math.round(avgArr[0]?.avg || 0), topCities, topQuality } });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
};

module.exports = { createEstimate, getEstimate, getStats };
