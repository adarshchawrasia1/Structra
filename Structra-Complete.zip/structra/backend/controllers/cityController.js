/**
 * controllers/cityController.js
 */
const City = require('../models/City');
const { CITY_RATES } = require('../services/calculationService');

const getCities = async (req, res) => {
  try {
    let cities = await City.find().sort({ tier: 1, name: 1 }).select('-__v');
    if (!cities.length) {
      cities = Object.entries(CITY_RATES).map(([slug, d]) => ({
        slug, name: d.name, region: d.region, baseRate: d.rate, tier: d.tier
      }));
    }
    return res.json({ success: true, count: cities.length, data: cities });
  } catch (err) {
    return res.status(500).json({ success: false, message: err.message });
  }
};

module.exports = { getCities };
