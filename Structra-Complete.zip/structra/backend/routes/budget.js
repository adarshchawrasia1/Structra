// routes/budget.js
const express = require('express');
const router  = express.Router();
const { body } = require('express-validator');
const { calcBudget } = require('../controllers/budgetController');
router.post('/', [body('budget').notEmpty().isFloat({min:1}), body('plotSize').notEmpty().isFloat({min:1})], calcBudget);
module.exports = router;
