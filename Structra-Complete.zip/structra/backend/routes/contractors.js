// routes/contractors.js
const express = require('express');
const router  = express.Router();
const { getContractors, getContractorById } = require('../controllers/contractorController');
router.get('/', getContractors);
router.get('/:id', getContractorById);
module.exports = router;
