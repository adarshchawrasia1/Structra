// routes/estimate.js
const express = require('express');
const router  = express.Router();
const { body } = require('express-validator');
const { createEstimate, getEstimate, getStats } = require('../controllers/estimateController');

const validate = [
  body('plotSize').notEmpty().isFloat({ min: 1 }).withMessage('Plot size must be a positive number'),
  body('plotUnit').optional().isIn(['sqft','sqm']),
  body('builtupPercentage').optional().isFloat({ min: 40, max: 100 }),
  body('floors').optional().isInt({ min: 1, max: 50 }),
  body('buildingType').optional().isIn(['residential','commercial','warehouse']),
  body('quality').optional().isIn(['basic','standard','premium']),
  body('city').notEmpty().isString().trim(),
  body('soilType').optional().isIn(['normal','rocky','loose','expansive']),
  body('locationType').optional().isIn(['urban','suburban','rural']),
  body('roadAccess').optional().isIn(['good','moderate','poor']),
  body('brickType').optional().isIn(['red','flyash','aac']),
];

router.post('/', validate, createEstimate);
router.get('/stats', getStats);
router.get('/:id', getEstimate);

module.exports = router;
