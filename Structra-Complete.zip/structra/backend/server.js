/**
 * ╔══════════════════════════════════════════════════╗
 * ║   STRUCTRA — Construction Cost Platform API      ║
 * ║   server.js — Express entry point                ║
 * ╚══════════════════════════════════════════════════╝
 */

const express    = require('express');
const cors       = require('cors');
const morgan     = require('morgan');
const helmet     = require('helmet');
const rateLimit  = require('express-rate-limit');
const dotenv     = require('dotenv');
const path       = require('path');

dotenv.config();

const connectDB  = require('./config/db');

// ── Route imports ─────────────────────────────────────────────
const estimateRoutes    = require('./routes/estimate');
const contractorRoutes  = require('./routes/contractors');
const budgetRoutes      = require('./routes/budget');
const cityRoutes        = require('./routes/cities');

// ── App init ──────────────────────────────────────────────────
const app  = express();
const PORT = process.env.PORT || 5000;

// ── Connect DB ────────────────────────────────────────────────
connectDB();

// ── Security middleware ───────────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: false,   // allow frontend resources
  crossOriginEmbedderPolicy: false
}));

// ── Rate limiting ─────────────────────────────────────────────
const limiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
  max:      parseInt(process.env.RATE_LIMIT_MAX)        || 150,
  message:  { success: false, message: 'Too many requests, please try again later.' }
});
app.use('/api/', limiter);

// ── CORS ──────────────────────────────────────────────────────
const allowedOrigins = [
  process.env.FRONTEND_URL,
  'http://localhost:5500',
  'http://127.0.0.1:5500',
  'http://localhost:3000',
  'http://localhost:5000',
  'null'  // file:// protocol
].filter(Boolean);

app.use(cors({
  origin: (origin, cb) => {
    if (!origin || allowedOrigins.includes(origin)) return cb(null, true);
    cb(new Error(`CORS blocked for origin: ${origin}`));
  },
  methods:     ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true
}));
app.options('*', cors());

// ── Body parsers ──────────────────────────────────────────────
app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: true }));

// ── Logging ───────────────────────────────────────────────────
if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
}

// ── Serve frontend from backend (optional, for deployment) ────
// Uncomment these lines if you want one server to serve everything:
// app.use(express.static(path.join(__dirname, '../frontend')));
// app.get('/', (req, res) => res.sendFile(path.join(__dirname, '../frontend/index.html')));

// ── API Routes ────────────────────────────────────────────────
app.use('/api/estimate',     estimateRoutes);
app.use('/api/contractors',  contractorRoutes);
app.use('/api/budget',       budgetRoutes);
app.use('/api/cities',       cityRoutes);

// ── Health check ──────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({
    success: true,
    status:  'Structra API is running ⚡',
    version: '1.0.0',
    time:    new Date().toISOString(),
    endpoints: {
      estimate:    'POST /api/estimate',
      budget:      'POST /api/budget',
      contractors: 'GET  /api/contractors?city=nagpur',
      cities:      'GET  /api/cities',
    }
  });
});

// ── 404 handler ───────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ success: false, message: `Route ${req.originalUrl} not found` });
});

// ── Global error handler ──────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('❌ Server error:', err.stack);
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Internal server error',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

// ── Start ─────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log('\n⚡  STRUCTRA API');
  console.log(`✅  Running  →  http://localhost:${PORT}`);
  console.log(`📦  Mode     →  ${process.env.NODE_ENV}`);
  console.log(`🍃  MongoDB  →  ${process.env.MONGODB_URI}\n`);
});

module.exports = app;
