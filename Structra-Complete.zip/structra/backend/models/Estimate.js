/**
 * models/Estimate.js — saved estimate records
 */
const mongoose = require('mongoose');

const EstimateSchema = new mongoose.Schema({
  // Inputs
  plotSize:          { type: Number, required: true, min: 1 },
  plotUnit:          { type: String, enum: ['sqft','sqm'], default: 'sqft' },
  builtupPercentage: { type: Number, default: 75, min: 40, max: 100 },
  floors:            { type: Number, default: 2, min: 1, max: 50 },
  buildingType:      { type: String, enum: ['residential','commercial','warehouse'], default: 'residential' },
  quality:           { type: String, enum: ['basic','standard','premium'], default: 'standard' },
  city:              { type: String, required: true, lowercase: true, trim: true },
  brickType:         { type: String, enum: ['red','flyash','aac'], default: 'red' },
  soilType:          { type: String, enum: ['normal','rocky','loose','expansive'], default: 'normal' },
  locationType:      { type: String, enum: ['urban','suburban','rural'], default: 'urban' },
  roadAccess:        { type: String, enum: ['good','moderate','poor'], default: 'good' },
  description:       { type: String, maxlength: 1000, default: '' },
  customPrices: {
    cementPerBag: { type: Number, default: null },
    steelPerKg:   { type: Number, default: null },
    labourPerDay: { type: Number, default: null },
  },
  // Results (stored for analytics)
  results: {
    totalCost:        Number,
    ratePerSqft:      Number,
    totalAreaSqft:    Number,
    builtupAreaSqft:  Number,
    costRangeMin:     Number,
    costRangeMax:     Number,
  },
  score: { type: Number, default: 0 },
  // Meta
  ipAddress: { type: String, default: '' },
}, { timestamps: true });

EstimateSchema.index({ city: 1, createdAt: -1 });
EstimateSchema.index({ buildingType: 1, quality: 1 });

module.exports = mongoose.model('Estimate', EstimateSchema);
