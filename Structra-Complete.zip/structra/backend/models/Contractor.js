/**
 * models/Contractor.js
 */
const mongoose = require('mongoose');

const ContractorSchema = new mongoose.Schema({
  name:             { type: String, required: true, trim: true },
  city:             { type: String, required: true, lowercase: true, trim: true, index: true },
  region:           { type: String, trim: true },
  rating:           { type: Number, min: 1, max: 5, default: 4.0 },
  totalReviews:     { type: Number, default: 0 },
  phone:            { type: String, trim: true },
  email:            { type: String, lowercase: true, trim: true },
  website:          { type: String, default: null },
  specialization:   { type: [String], default: ['Residential'] },
  minRate:          { type: Number, required: true },
  maxRate:          { type: Number, required: true },
  experience:       { type: Number, default: 5 },
  completedProjects:{ type: Number, default: 0 },
  verified:         { type: Boolean, default: false },
  featured:         { type: Boolean, default: false },
  available:        { type: Boolean, default: true },
}, { timestamps: true });

ContractorSchema.index({ city: 1, featured: -1, rating: -1 });

ContractorSchema.virtual('priceRange').get(function () {
  return `₹${this.minRate.toLocaleString('en-IN')}–₹${this.maxRate.toLocaleString('en-IN')}/sqft`;
});
ContractorSchema.set('toJSON', { virtuals: true });

module.exports = mongoose.model('Contractor', ContractorSchema);
