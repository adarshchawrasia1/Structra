/**
 * models/City.js
 */
const mongoose = require('mongoose');

const CitySchema = new mongoose.Schema({
  name:         { type: String, required: true, trim: true },
  slug:         { type: String, required: true, unique: true, lowercase: true, trim: true },
  region:       { type: String, trim: true },
  baseRate:     { type: Number, required: true },
  multiplier:   { type: Number, default: 1.0 },
  tier:         { type: String, enum: ['metro','tier1','tier2','tier3'], default: 'tier2' },
  hasContractors: { type: Boolean, default: false },
}, { timestamps: true });

module.exports = mongoose.model('City', CitySchema);
