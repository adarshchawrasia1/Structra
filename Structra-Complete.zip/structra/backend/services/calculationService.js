/**
 * services/calculationService.js
 * ─────────────────────────────────────────────────────────────
 * STRUCTRA core engine — all cost intelligence lives here.
 * Called by controllers; no Express code here.
 */

// ── City Base Rates ───────────────────────────────────────────
// Base rate per sqft: Standard quality, Residential, Normal soil, Urban
const CITY_RATES = {
  nagpur:     { rate: 1800, name: 'Nagpur',     region: 'Maharashtra',  tier: 'tier2' },
  pune:       { rate: 2200, name: 'Pune',       region: 'Maharashtra',  tier: 'tier1' },
  mumbai:     { rate: 3000, name: 'Mumbai',     region: 'Maharashtra',  tier: 'metro' },
  delhi:      { rate: 2800, name: 'Delhi',      region: 'Delhi NCR',    tier: 'metro' },
  bangalore:  { rate: 2600, name: 'Bangalore',  region: 'Karnataka',    tier: 'metro' },
  hyderabad:  { rate: 2000, name: 'Hyderabad',  region: 'Telangana',    tier: 'tier1' },
  chennai:    { rate: 2100, name: 'Chennai',    region: 'Tamil Nadu',   tier: 'tier1' },
  ahmedabad:  { rate: 1700, name: 'Ahmedabad',  region: 'Gujarat',      tier: 'tier1' },
  kolkata:    { rate: 1900, name: 'Kolkata',    region: 'West Bengal',  tier: 'metro' },
  jaipur:     { rate: 1600, name: 'Jaipur',     region: 'Rajasthan',    tier: 'tier2' },
  lucknow:    { rate: 1500, name: 'Lucknow',    region: 'U.P.',         tier: 'tier2' },
  surat:      { rate: 1750, name: 'Surat',      region: 'Gujarat',      tier: 'tier2' },
  bhopal:     { rate: 1550, name: 'Bhopal',     region: 'M.P.',         tier: 'tier2' },
  coimbatore: { rate: 1850, name: 'Coimbatore', region: 'Tamil Nadu',   tier: 'tier2' },
  indore:     { rate: 1600, name: 'Indore',     region: 'M.P.',         tier: 'tier2' },
};

// ── Quality Ranges ────────────────────────────────────────────
const QUALITY_RANGES = {
  basic:    { min: 1400, max: 1800, mid: 1600, label: 'Basic' },
  standard: { min: 1800, max: 2500, mid: 2150, label: 'Standard' },
  premium:  { min: 2500, max: 4000, mid: 3250, label: 'Premium' },
};

// ── Building Type Multipliers ─────────────────────────────────
const TYPE_MULTIPLIERS = {
  residential: 1.00,
  commercial:  1.15,
  warehouse:   0.85,
};

// ── Reality Layer Multipliers ─────────────────────────────────
const SOIL_MULTIPLIERS = {
  normal:    { mult: 1.00, label: 'Normal/Hard murrum soil' },
  rocky:     { mult: 1.08, label: 'Rocky/Hard rock soil',    note: 'Drilling and blasting required — increases foundation cost by ~8%.' },
  loose:     { mult: 1.15, label: 'Loose/Sandy soil',        note: 'Requires deeper foundations and pile reinforcement — adds ~15% to foundation cost.' },
  expansive: { mult: 1.18, label: 'Black cotton/Expansive soil', note: 'High-risk soil requiring pile or raft foundation — adds ~18% to base construction cost.' },
};

const LOCATION_MULTIPLIERS = {
  urban:    { mult: 1.00, label: 'Urban' },
  suburban: { mult: 0.95, label: 'Suburban' },
  rural:    { mult: 0.88, label: 'Rural' },
};

const ROAD_MULTIPLIERS = {
  good:     { mult: 1.00 },
  moderate: { mult: 1.02 },
  poor:     { mult: 1.05 },
};

const BRICK_MULTIPLIERS = {
  red:     { mult: 1.00, name: 'Red Bricks' },
  flyash:  { mult: 0.92, name: 'Fly Ash Bricks' },
  aac:     { mult: 0.95, name: 'AAC Blocks' },
};

// ── Cost Breakdown Ratios (CPWD India averages) ───────────────
const BREAKDOWN_RATIOS = {
  cement:    0.12,
  steel:     0.18,
  bricks:    0.11,
  sandGravel:0.10,
  labour:    0.28,
  finishing: 0.21,
};

const BREAKDOWN_COLORS = {
  cement: '#F59E0B', steel: '#3B82F6', bricks: '#EF4444',
  sandGravel: '#8B5CF6', labour: '#10B981', finishing: '#06B6D4'
};

// ── Helpers ───────────────────────────────────────────────────
const clamp  = (v, mn, mx) => Math.min(Math.max(v, mn), mx);
const toSqft = (size, unit) => unit === 'sqm' ? size * 10.7639 : size;
const fmtINR = n => '₹' + Math.round(n).toLocaleString('en-IN');
const fmtL   = n => {
  if (n >= 10000000) return (n / 10000000).toFixed(2) + ' Cr';
  if (n >= 100000)   return (n / 100000).toFixed(2)   + ' L';
  return Math.round(n).toLocaleString('en-IN');
};

// ── Material Custom Price Adjustment ─────────────────────────
const applyCustomPrices = (baseRate, customPrices = {}) => {
  const MARKET = { cementPerBag: 380, steelPerKg: 65, labourPerDay: 750 };
  let adj = 0;
  if (customPrices.cementPerBag) adj += ((customPrices.cementPerBag - MARKET.cementPerBag) / MARKET.cementPerBag) * BREAKDOWN_RATIOS.cement;
  if (customPrices.steelPerKg)   adj += ((customPrices.steelPerKg   - MARKET.steelPerKg)   / MARKET.steelPerKg)   * BREAKDOWN_RATIOS.steel;
  if (customPrices.labourPerDay) adj += ((customPrices.labourPerDay - MARKET.labourPerDay) / MARKET.labourPerDay) * BREAKDOWN_RATIOS.labour;
  return 1 + adj;
};

// ── Cost Breakdown Calculator ─────────────────────────────────
const calcBreakdown = (totalCost) => {
  const keys   = Object.keys(BREAKDOWN_RATIOS);
  const result = {};
  let allocated = 0;
  keys.forEach((key, i) => {
    const amount = i === keys.length - 1
      ? Math.round(totalCost - allocated)
      : Math.round(totalCost * BREAKDOWN_RATIOS[key]);
    result[key] = { amount, percentage: Math.round(BREAKDOWN_RATIOS[key] * 100), color: BREAKDOWN_COLORS[key] };
    if (i < keys.length - 1) allocated += amount;
  });
  return result;
};

// ── Material Quantities (CPWD norms) ─────────────────────────
const calcQuantities = (totalAreaSqft, buildingType, brickType) => {
  const bricksPerSqft = buildingType === 'warehouse' ? 5 : 8;
  return {
    cementBags:    Math.round(totalAreaSqft * 0.40),
    steelKg:       Math.round(totalAreaSqft * 4.5),
    steelTonnes:   parseFloat((totalAreaSqft * 4.5 / 1000).toFixed(2)),
    bricks:        Math.round(totalAreaSqft * bricksPerSqft),
    brickType:     BRICK_MULTIPLIERS[brickType]?.name || 'Red Bricks',
    sandCuft:      Math.round(totalAreaSqft * 1.5),
    aggregateCuft: Math.round(totalAreaSqft * 0.9),
    paintLitres:   Math.round(totalAreaSqft * 0.12),
    tilesSqft:     Math.round(totalAreaSqft * 1.15),
    waterKilolitres: Math.round(totalAreaSqft * 50 / 1000),
  };
};

// ── Timeline Calculator ───────────────────────────────────────
const calcTimeline = (floors, soilType, buildingType) => {
  const baseMonths = floors <= 1 ? 5 : floors <= 2 ? 8 : floors <= 4 ? 12 : 16;
  const soilBonus  = soilType === 'expansive' ? 3 : soilType === 'loose' ? 2 : soilType === 'rocky' ? 1 : 0;
  const total = baseMonths + soilBonus;
  return {
    totalMonthsMin: total,
    totalMonthsMax: total + 2,
    phases: [
      { name: 'Site Preparation & Foundation', pct: 0.12, months: `Month 1–${Math.ceil(total * 0.2)}`,  color: '#F59E0B' },
      { name: 'Plinth & Basement',             pct: 0.10, months: `Month ${Math.ceil(total * 0.2)}–${Math.ceil(total * 0.35)}`, color: '#6366F1' },
      { name: 'Superstructure (All Floors)',   pct: 0.30, months: `Month ${Math.ceil(total * 0.35)}–${Math.ceil(total * 0.65)}`, color: '#3B82F6' },
      { name: 'Roof Slab & Overhead',          pct: 0.10, months: `Month ${Math.ceil(total * 0.65)}–${Math.ceil(total * 0.75)}`, color: '#8B5CF6' },
      { name: 'Finishing & MEP Works',         pct: 0.30, months: `Month ${Math.ceil(total * 0.75)}–${Math.ceil(total * 0.90)}`, color: '#10B981' },
      { name: 'Fittings & Handover',           pct: 0.08, months: `Month ${Math.ceil(total * 0.90)}–${total}`, color: '#06B6D4' },
    ]
  };
};

// ── Payment Schedule ──────────────────────────────────────────
const calcPaymentSchedule = (totalCost, floors) => [
  { phase: 'Foundation & Site Prep', months: 'Month 1–2',            pct: 0.15, amount: Math.round(totalCost * 0.15) },
  { phase: 'Plinth & Basement',      months: 'Month 2–3',            pct: 0.10, amount: Math.round(totalCost * 0.10) },
  { phase: 'Superstructure',         months: `Month 3–${3 + floors}`, pct: 0.30, amount: Math.round(totalCost * 0.30) },
  { phase: 'Roof & Overhead',        months: `Month ${3 + floors}`,   pct: 0.10, amount: Math.round(totalCost * 0.10) },
  { phase: 'Plastering & MEP',       months: `Month ${4 + floors}–${6 + floors}`, pct: 0.20, amount: Math.round(totalCost * 0.20) },
  { phase: 'Finishing & Fittings',   months: `Month ${6 + floors}+`,  pct: 0.15, amount: Math.round(totalCost * 0.15) },
];

// ── Structra Score ────────────────────────────────────────────
const calcScore = ({ quality, soilMult, locMult, roadMult, brickType, builtupPct }) => {
  let score = 100;
  if (quality === 'premium') score -= 15;
  if (quality === 'basic')   score += 5;
  if (soilMult > 1)  score -= Math.round((soilMult - 1) * 80);
  if (locMult < 1)   score += Math.round((1 - locMult) * 20);
  if (roadMult > 1)  score -= 5;
  if (brickType === 'flyash') score += 5;
  if (brickType === 'aac')    score += 3;
  if (builtupPct > 80)        score -= 8;
  return Math.min(98, Math.max(35, score));
};

// ── Smart Suggestions ─────────────────────────────────────────
const generateSuggestions = ({ totalCost, quality, buildingType, totalAreaSqft, breakdown, floors, soilMult, brickType }) => {
  const suggestions = [];
  const sorted = Object.entries(breakdown).sort((a, b) => b[1].amount - a[1].amount);
  const topCat = sorted[0][0];
  const topPct = sorted[0][1].percentage;

  suggestions.push({ type: 'info', icon: '📊', title: 'Top cost driver', message: `${topCat} contributes ${topPct}% of your total cost (${fmtL(sorted[0][1].amount)}). This is your highest optimization target.` });

  if (quality !== 'basic') {
    const lq = quality === 'premium' ? 'standard' : 'basic';
    const saving = Math.round(totalCost - (totalAreaSqft * QUALITY_RANGES[lq].mid));
    if (saving > 0) suggestions.push({ type: 'saving', icon: '📉', title: 'Quality switch opportunity', message: `Switching from ${quality} to ${lq} quality saves approximately ${fmtL(saving)} — ${Math.round(saving / totalCost * 100)}% reduction.`, saving: fmtL(saving) });
  }

  const save10 = Math.round(totalCost * 0.10);
  suggestions.push({ type: 'saving', icon: '📐', title: 'Area reduction', message: `Reducing built-up area by 10% saves ${fmtL(save10)}. Consider if you need all floors at full built-up coverage.`, saving: fmtL(save10) });

  if (brickType === 'red') {
    const saveFlyAsh = Math.round(breakdown.bricks?.amount * 0.08 || 0);
    suggestions.push({ type: 'saving', icon: '🧱', title: 'Fly ash bricks upgrade', message: `Replacing red bricks with fly ash bricks saves ~8% on brick cost (${fmtL(saveFlyAsh)}). They are also eco-friendly and have better thermal insulation.`, saving: fmtL(saveFlyAsh) });
  }

  const typeTips = {
    residential: 'Use HYSD bars (Fe-500) instead of mild steel for column reinforcement — stronger and slightly cheaper per unit strength.',
    commercial:  'Prefabricated steel structural elements can cut commercial build time by 20% and reduce waste significantly.',
    warehouse:   'Pre-engineered buildings (PEB) are 25–30% cheaper than conventional RCC for large warehouse spans.',
  };
  suggestions.push({ type: 'tip', icon: '🏗️', title: 'Construction optimization', message: typeTips[buildingType] });

  if (soilMult > 1) suggestions.push({ type: 'risk', icon: '⚠️', title: 'Soil risk — get professional advice', message: 'Your soil type increases foundation cost significantly. Get a Soil Bearing Capacity (SBC) test done before designing foundation. A structural engineer must design the foundation — do not rely on estimates for this.' });

  suggestions.push({ type: 'warning', icon: '⚠️', title: 'Contingency fund is mandatory', message: `Set aside ${fmtL(totalCost * 0.12)} (12%) as contingency. This covers material price spikes, design changes, weather delays, and govt approval fees.` });

  suggestions.push({ type: 'risk', icon: '🔌', title: 'Hidden costs — often forgotten', message: `Budget separately for: Govt plan approval (₹50K–₹2L), water/electricity connection (₹50K–₹1.5L), scaffolding, construction insurance, watchman charges, and material storage.` });

  if (floors > 1) suggestions.push({ type: 'tip', icon: '🏢', title: 'Multi-floor efficiency', message: `Upper floors share foundation and structural costs. Adding floors is 5–8% more cost-efficient per sqft than building the same area on ground level.` });

  return suggestions;
};

// ═════════════════════════════════════════════════════════════
// ── MAIN ESTIMATE CALCULATOR ─────────────────────────────────
// ═════════════════════════════════════════════════════════════
const calculateEstimate = (inputs) => {
  const {
    plotSize, plotUnit = 'sqft',
    builtupPercentage = 75, floors = 2,
    city = 'nagpur', buildingType = 'residential',
    quality = 'standard', brickType = 'red',
    soilType = 'normal', locationType = 'urban',
    roadAccess = 'good', customPrices = {}
  } = inputs;

  // 1. Areas
  const plotSqft      = toSqft(Number(plotSize), plotUnit);
  const builtupArea   = plotSqft * (builtupPercentage / 100);
  const totalAreaSqft = builtupArea * Number(floors);

  // 2. Reality-layer multipliers
  const cityData   = CITY_RATES[city]       || CITY_RATES.nagpur;
  const qr         = QUALITY_RANGES[quality]|| QUALITY_RANGES.standard;
  const soilData   = SOIL_MULTIPLIERS[soilType]       || SOIL_MULTIPLIERS.normal;
  const locData    = LOCATION_MULTIPLIERS[locationType]|| LOCATION_MULTIPLIERS.urban;
  const roadData   = ROAD_MULTIPLIERS[roadAccess]      || ROAD_MULTIPLIERS.good;
  const brickData  = BRICK_MULTIPLIERS[brickType]      || BRICK_MULTIPLIERS.red;
  const typeMult   = TYPE_MULTIPLIERS[buildingType]    || 1.0;

  // 3. Effective rate
  let baseRate = cityData.rate * typeMult * (qr.mid / 2150);
  baseRate = clamp(baseRate, qr.min, qr.max);
  const realityMult    = soilData.mult * locData.mult * roadData.mult * brickData.mult;
  const customMult     = applyCustomPrices(baseRate, customPrices);
  let   effectiveRate  = Math.round(baseRate * realityMult * customMult);
  effectiveRate        = clamp(effectiveRate, qr.min, qr.max + 1000);

  // 4. Costs
  const totalCost   = Math.round(totalAreaSqft * effectiveRate);
  const costRangeMin= Math.round(totalAreaSqft * qr.min);
  const costRangeMax= Math.round(totalAreaSqft * qr.max);

  // 5. Breakdown
  const breakdown = calcBreakdown(totalCost);

  // 6. Quantities
  const quantities = calcQuantities(totalAreaSqft, buildingType, brickType);

  // 7. Timeline
  const timeline = calcTimeline(Number(floors), soilType, buildingType);
  timeline.phases.forEach(ph => { ph.cost = Math.round(totalCost * ph.pct); });

  // 8. Payment schedule
  const paymentSchedule = calcPaymentSchedule(totalCost, Number(floors));

  // 9. Structra Score
  const score = calcScore({
    quality, soilMult: soilData.mult, locMult: locData.mult,
    roadMult: roadData.mult, brickType, builtupPct: builtupPercentage
  });

  // 10. Suggestions
  const suggestions = generateSuggestions({
    totalCost, quality, buildingType, totalAreaSqft,
    breakdown, floors: Number(floors), soilMult: soilData.mult, brickType
  });

  // 11. Scenario comparison
  const scenarios = ['basic', 'standard', 'premium'].map(q => {
    const sqr = QUALITY_RANGES[q];
    let r = cityData.rate * typeMult * (sqr.mid / 2150) * realityMult;
    r = clamp(r, sqr.min, sqr.max);
    const cost = Math.round(totalAreaSqft * r);
    return {
      quality: q,
      ratePerSqft: Math.round(r),
      totalCost: cost,
      isCurrent: q === quality,
      savingVsCurrent: q !== quality ? totalCost - cost : 0,
    };
  });

  // 12. Reality layer impact
  const soilImpact = soilData.mult > 1 ? Math.round(totalCost * (soilData.mult - 1) / soilData.mult) : 0;

  return {
    inputs: { plotSqft: Math.round(plotSqft), builtupPercentage, floors: Number(floors), buildingType, quality, city, brickType, soilType, locationType },
    results: {
      builtupAreaSqft: Math.round(builtupArea),
      totalAreaSqft:   Math.round(totalAreaSqft),
      ratePerSqft:     effectiveRate,
      totalCost,
      costRangeMin,
      costRangeMax,
      breakdown,
      quantities,
      soilImpact,
    },
    score,
    timeline,
    paymentSchedule,
    scenarios,
    suggestions,
    realityLayer: {
      soil:     { type: soilType,     mult: soilData.mult,  label: soilData.label, note: soilData.note },
      location: { type: locationType, mult: locData.mult,   label: locData.label  },
      road:     { type: roadAccess,   mult: roadData.mult                          },
      brick:    { type: brickType,    mult: brickData.mult, name: brickData.name  },
    },
    cityInfo: cityData,
  };
};

// ── BUDGET PLANNER ────────────────────────────────────────────
const calculateBudget = (inputs) => {
  const {
    budget, plotSize, plotUnit = 'sqft',
    builtupPercentage = 75, buildingType = 'residential',
    quality = 'standard', city = 'nagpur',
    soilType = 'normal', locationType = 'urban', brickType = 'red'
  } = inputs;

  const cityData  = CITY_RATES[city]       || CITY_RATES.nagpur;
  const qr        = QUALITY_RANGES[quality]|| QUALITY_RANGES.standard;
  const soilMult  = SOIL_MULTIPLIERS[soilType]?.mult       || 1;
  const locMult   = LOCATION_MULTIPLIERS[locationType]?.mult|| 1;
  const brickMult = BRICK_MULTIPLIERS[brickType]?.mult      || 1;
  const typeMult  = TYPE_MULTIPLIERS[buildingType]           || 1;

  let rate = cityData.rate * typeMult * (qr.mid / 2150) * soilMult * locMult * brickMult;
  rate = Math.round(clamp(rate, qr.min, qr.max));

  const plotSqft      = toSqft(Number(plotSize), plotUnit);
  const areaPerFloor  = plotSqft * (builtupPercentage / 100);
  const maxTotalArea  = Math.floor(Number(budget) / rate);
  const maxFloors     = Math.max(1, Math.floor(maxTotalArea / areaPerFloor));
  const actualArea    = areaPerFloor * maxFloors;
  const estimatedCost = Math.round(actualArea * rate);

  const bestQuality = rate <= 1800 ? 'basic' : rate <= 2500 ? 'standard' : 'premium';

  return {
    budget:            Number(budget),
    ratePerSqft:       rate,
    maxTotalAreaSqft:  maxTotalArea,
    maxBuildableArea:  Math.round(actualArea),
    maxFloors,
    estimatedCost,
    remainingBudget:   Math.max(0, Number(budget) - estimatedCost),
    bestQualityFit:    bestQuality,
    recommendation:    `At ₹${rate.toLocaleString('en-IN')}/sqft, your budget of ${fmtL(Number(budget))} supports ${maxFloors} floor(s) of ${Math.round(areaPerFloor).toLocaleString('en-IN')} sqft each.`,
  };
};

module.exports = {
  calculateEstimate,
  calculateBudget,
  CITY_RATES,
  QUALITY_RANGES,
  TYPE_MULTIPLIERS,
  SOIL_MULTIPLIERS,
  LOCATION_MULTIPLIERS,
};
