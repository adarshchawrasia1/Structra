# 📤 GITHUB UPLOAD GUIDE — Structra

Complete step-by-step instructions to upload your Structra project to GitHub.

---

## ✅ PREREQUISITES

Before starting, make sure you have:
- [ ] A **GitHub account** (free at github.com)
- [ ] **Git installed** on your computer

### Check if Git is installed:
```bash
git --version
# Should show: git version 2.x.x
```

### If Git is NOT installed:
- **Windows:** Download from https://git-scm.com/download/win → Install with defaults
- **Mac:** Run `xcode-select --install` in Terminal
- **Linux/Ubuntu:** `sudo apt install git`

---

## STEP 1 — Create a GitHub Repository

1. Go to **https://github.com** and log in
2. Click the **"+"** button (top-right) → **"New repository"**
3. Fill in:
   - **Repository name:** `structra`
   - **Description:** `Intelligent Construction Cost Estimator — India`
   - **Visibility:** Public (so employers/recruiters can see it)
   - **DO NOT** check "Add README" (you already have one)
4. Click **"Create repository"**
5. **Copy the URL** shown — it will look like:
   `https://github.com/YOUR_USERNAME/structra.git`

---

## STEP 2 — Set Up Git (First time only)

Open **Terminal** (Mac/Linux) or **Git Bash** (Windows) and run:

```bash
git config --global user.name "Your Name"
git config --global user.email "your.email@gmail.com"
```

Replace with your actual name and the email you used for GitHub.

---

## STEP 3 — Navigate to Your Project Folder

```bash
# On Windows (example):
cd C:\Users\Adarsh\Downloads\structra

# On Mac/Linux (example):
cd ~/Downloads/structra

# Verify you're in the right place:
ls
# Should show: frontend/  backend/  README.md  .gitignore
```

---

## STEP 4 — Initialize Git and Make First Commit

```bash
# 1. Initialize git in this folder
git init

# 2. Add all files (the .gitignore will exclude node_modules and .env automatically)
git add .

# 3. Check what will be committed (optional but recommended)
git status

# 4. Create your first commit
git commit -m "🚀 Initial commit — Structra Construction Cost Platform"
```

---

## STEP 5 — Connect to GitHub and Push

```bash
# 1. Connect your local repo to GitHub
#    Replace YOUR_USERNAME with your actual GitHub username
git remote add origin https://github.com/YOUR_USERNAME/structra.git

# 2. Rename default branch to 'main' (GitHub standard)
git branch -M main

# 3. Push your code to GitHub
git push -u origin main
```

When prompted:
- **Username:** your GitHub username
- **Password:** use a **Personal Access Token** (NOT your password)

### How to get a Personal Access Token:
1. GitHub → Settings (top-right avatar) → Developer settings
2. Personal access tokens → Tokens (classic) → Generate new token
3. Check: `repo` scope
4. Click Generate → **Copy the token immediately** (shown only once)
5. Paste it as your "password" when Git asks

---

## STEP 6 — Verify Upload

1. Go to `https://github.com/YOUR_USERNAME/structra`
2. You should see all your files listed
3. The README.md will display automatically on the page

---

## STEP 7 — Make Your Repository Impressive

### Add a good description on GitHub:
1. On your repo page, click the ⚙️ gear icon next to "About"
2. Add description: `⚡ Structra — Intelligent Construction Cost Platform for India. Reality-layer pricing, AI optimization, material quantities, timeline planning.`
3. Add topics (tags): `construction` `estimator` `india` `nodejs` `mongodb` `expressjs` `html` `javascript`
4. Click Save

---

## 📁 WHAT GETS UPLOADED (and what doesn't)

| File/Folder | Uploaded? | Reason |
|---|---|---|
| `frontend/index.html` | ✅ YES | Main website file |
| `backend/server.js` | ✅ YES | Backend entry point |
| `backend/models/` | ✅ YES | Database schemas |
| `backend/routes/` | ✅ YES | API routes |
| `backend/services/` | ✅ YES | Core calculation engine |
| `backend/config/seed.js` | ✅ YES | Seed script |
| `backend/.env.example` | ✅ YES | Template (no real secrets) |
| `README.md` | ✅ YES | Project documentation |
| `.gitignore` | ✅ YES | Git config |
| `backend/.env` | ❌ NO | Contains your real passwords |
| `backend/node_modules/` | ❌ NO | Too large, auto-excluded |

---

## 🔄 HOW TO UPDATE GITHUB AFTER CHANGES

Every time you change your code:

```bash
# 1. Go to your project folder
cd path/to/structra

# 2. See what changed
git status

# 3. Add changed files
git add .

# 4. Commit with a message describing what you changed
git commit -m "✨ Add soil type calculator feature"

# 5. Push to GitHub
git push
```

---

## 💡 USEFUL GIT COMMANDS

```bash
git status              # See what's changed
git log --oneline       # See commit history  
git diff                # See exact changes
git pull                # Get latest from GitHub
git branch              # List branches
```

---

## 🌐 DEPLOY THE FRONTEND FREE (Bonus)

To make your site live on the internet for free:

### Option 1 — GitHub Pages (easiest, frontend only)
1. Go to your repo on GitHub
2. Settings → Pages → Source → Deploy from branch
3. Branch: `main`, Folder: `/frontend`
4. Click Save
5. Your site goes live at: `https://YOUR_USERNAME.github.io/structra`

### Option 2 — Vercel (full-stack, recommended)
1. Go to https://vercel.com → Sign up with GitHub
2. Click "New Project" → Import your `structra` repo
3. Set Root Directory to `backend`
4. Add Environment Variables: `MONGODB_URI`, `PORT`, etc.
5. Deploy → get a live URL like `https://structra.vercel.app`

### Option 3 — Render (free backend hosting)
1. Go to https://render.com → Sign up with GitHub
2. New → Web Service → Connect your repo
3. Build command: `cd backend && npm install`
4. Start command: `cd backend && node server.js`
5. Add environment variables
6. Free tier available

---

## ❓ COMMON ERRORS & FIXES

**Error: `git push` asks for password repeatedly**
→ Use a Personal Access Token (see Step 5)
→ Or set up SSH keys: https://docs.github.com/en/authentication/connecting-to-github-with-ssh

**Error: `remote: Repository not found`**
→ Check the URL: `git remote -v`
→ Fix: `git remote set-url origin https://github.com/YOUR_USERNAME/structra.git`

**Error: `fatal: not a git repository`**
→ You're in the wrong folder. Run `git init` in the structra/ folder.

**Error: `Updates were rejected because tip of current branch is behind`**
→ Run: `git pull origin main --rebase` then `git push`

**node_modules accidentally committed (repo too large)**
→ Add to .gitignore, then:
```bash
git rm -r --cached node_modules
git commit -m "Remove node_modules from tracking"
git push
```

---

*Built by Adarsh · DPGU University Pune · CSE*
